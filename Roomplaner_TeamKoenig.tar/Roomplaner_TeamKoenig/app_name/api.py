from . import models
from . import serializers
from rest_framework import viewsets, permissions


class RoomViewSet(viewsets.ModelViewSet):
    """ViewSet for the Room class"""

    queryset = models.Room.objects.all()
    serializer_class = serializers.RoomSerializer
    permission_classes = [permissions.IsAuthenticated]


class ReservationViewSet(viewsets.ModelViewSet):
    """ViewSet for the Reservation class"""

    queryset = models.Reservation.objects.all()
    serializer_class = serializers.ReservationSerializer
    permission_classes = [permissions.IsAuthenticated]


class ReasonViewSet(viewsets.ModelViewSet):
    """ViewSet for the Reason class"""

    queryset = models.Reason.objects.all()
    serializer_class = serializers.ReasonSerializer
    permission_classes = [permissions.IsAuthenticated]


class UserViewSet(viewsets.ModelViewSet):
    """ViewSet for the User class"""

    queryset = models.User.objects.all()
    serializer_class = serializers.UserSerializer
    permission_classes = [permissions.IsAuthenticated]


class calendarViewSet(viewsets.ModelViewSet):
    """ViewSet for the calendar class"""

    queryset = models.calendar.objects.all()
    serializer_class = serializers.calendarSerializer
    permission_classes = [permissions.IsAuthenticated]


class timeslotsViewSet(viewsets.ModelViewSet):
    """ViewSet for the timeslots class"""

    queryset = models.timeslots.objects.all()
    serializer_class = serializers.timeslotsSerializer
    permission_classes = [permissions.IsAuthenticated]


