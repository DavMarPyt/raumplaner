from django.urls import reverse
from django_extensions.db.fields import AutoSlugField
from django.contrib.postgres.fields.ranges import DateRangeField
from django.contrib.postgres.fields.ranges import DateTimeRangeField
from django.db.models import BooleanField
from django.db.models import CharField
from django.db.models import DateTimeField
from django.db.models import EmailField
from django.db.models import TextField
from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import get_user_model
from django.contrib.auth import models as auth_models
from django.db import models as models
from django_extensions.db import fields as extension_fields


class Room(models.Model):

    # Fields
    name = models.CharField(max_length=255)
    created = models.DateTimeField(auto_now_add=True, editable=False)
    last_updated = models.DateTimeField(auto_now=True, editable=False)
    roomnumber = models.TextField(max_length=200)
    building = models.TextField(max_length=200)
    email = models.EmailField()


    class Meta:
        ordering = ('-created',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('app_name_room_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('app_name_room_update', args=(self.pk,))


class Reservation(models.Model):

    # Fields
    name = models.CharField(max_length=255)
    created = models.DateTimeField(auto_now_add=True, editable=False)
    last_updated = models.DateTimeField(auto_now=True, editable=False)


    class Meta:
        ordering = ('-created',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('app_name_reservation_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('app_name_reservation_update', args=(self.pk,))


class Reason(models.Model):

    # Fields
    name = models.CharField(max_length=255)
    created = models.DateTimeField(auto_now_add=True, editable=False)
    last_updated = models.DateTimeField(auto_now=True, editable=False)
    description = models.TextField(max_length=100)


    class Meta:
        ordering = ('-created',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('app_name_reason_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('app_name_reason_update', args=(self.pk,))


class User(models.Model):

    # Fields
    name = models.CharField(max_length=255)
    created = models.DateTimeField(auto_now_add=True, editable=False)
    last_updated = models.DateTimeField(auto_now=True, editable=False)
    email = models.EmailField()
    admin = models.BooleanField()
    password = models.CharField(max_length=30)


    class Meta:
        ordering = ('-created',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('app_name_user_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('app_name_user_update', args=(self.pk,))


class calendar(models.Model):

    # Fields
    date = DateRangeField()
    datetime = DateTimeRangeField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('app_name_calendar_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('app_name_calendar_update', args=(self.pk,))


class timeslots(models.Model):

    # Fields
    name = models.CharField(max_length=255)
    created = models.DateTimeField(auto_now_add=True, editable=False)
    last_updated = models.DateTimeField(auto_now=True, editable=False)


    class Meta:
        ordering = ('-created',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('app_name_timeslots_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('app_name_timeslots_update', args=(self.pk,))


