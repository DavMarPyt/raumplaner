from django.views.generic import DetailView, ListView, UpdateView, CreateView
from .models import Room, Reservation, Reason, User, calendar, timeslots
from .forms import RoomForm, ReservationForm, ReasonForm, UserForm, calendarForm, timeslotsForm


class RoomListView(ListView):
    model = Room


class RoomCreateView(CreateView):
    model = Room
    form_class = RoomForm


class RoomDetailView(DetailView):
    model = Room


class RoomUpdateView(UpdateView):
    model = Room
    form_class = RoomForm


class ReservationListView(ListView):
    model = Reservation


class ReservationCreateView(CreateView):
    model = Reservation
    form_class = ReservationForm


class ReservationDetailView(DetailView):
    model = Reservation


class ReservationUpdateView(UpdateView):
    model = Reservation
    form_class = ReservationForm


class ReasonListView(ListView):
    model = Reason


class ReasonCreateView(CreateView):
    model = Reason
    form_class = ReasonForm


class ReasonDetailView(DetailView):
    model = Reason


class ReasonUpdateView(UpdateView):
    model = Reason
    form_class = ReasonForm


class UserListView(ListView):
    model = User


class UserCreateView(CreateView):
    model = User
    form_class = UserForm


class UserDetailView(DetailView):
    model = User


class UserUpdateView(UpdateView):
    model = User
    form_class = UserForm


class calendarListView(ListView):
    model = calendar


class calendarCreateView(CreateView):
    model = calendar
    form_class = calendarForm


class calendarDetailView(DetailView):
    model = calendar


class calendarUpdateView(UpdateView):
    model = calendar
    form_class = calendarForm


class timeslotsListView(ListView):
    model = timeslots


class timeslotsCreateView(CreateView):
    model = timeslots
    form_class = timeslotsForm


class timeslotsDetailView(DetailView):
    model = timeslots


class timeslotsUpdateView(UpdateView):
    model = timeslots
    form_class = timeslotsForm

