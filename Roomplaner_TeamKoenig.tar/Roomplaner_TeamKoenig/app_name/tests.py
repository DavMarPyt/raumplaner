import unittest
from django.urls import reverse
from django.test import Client
from .models import Room, Reservation, Reason, User, calendar, timeslots
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType


def create_django_contrib_auth_models_user(**kwargs):
    defaults = {}
    defaults["username"] = "username"
    defaults["email"] = "username@tempurl.com"
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_django_contrib_auth_models_group(**kwargs):
    defaults = {}
    defaults["name"] = "group"
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_django_contrib_contenttypes_models_contenttype(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_room(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults["roomnumber"] = "roomnumber"
    defaults["building"] = "building"
    defaults["email"] = "email"
    defaults.update(**kwargs)
    return Room.objects.create(**defaults)


def create_reservation(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults.update(**kwargs)
    return Reservation.objects.create(**defaults)


def create_reason(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults.update(**kwargs)
    return Reason.objects.create(**defaults)


def create_user(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults["email"] = "email"
    defaults["admin"] = "admin"
    defaults["password"] = "password"
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_calendar(**kwargs):
    defaults = {}
    defaults["date"] = "date"
    defaults["datetime"] = "datetime"
    defaults.update(**kwargs)
    return calendar.objects.create(**defaults)


def create_timeslots(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults.update(**kwargs)
    return timeslots.objects.create(**defaults)


class RoomViewTest(unittest.TestCase):
    '''
    Tests for Room
    '''
    def setUp(self):
        self.client = Client()

    def test_list_room(self):
        url = reverse('app_name_room_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_room(self):
        url = reverse('app_name_room_create')
        data = {
            "name": "name",
            "roomnumber": "roomnumber",
            "building": "building",
            "email": "email",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_room(self):
        room = create_room()
        url = reverse('app_name_room_detail', args=[room.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_room(self):
        room = create_room()
        data = {
            "name": "name",
            "roomnumber": "roomnumber",
            "building": "building",
            "email": "email",
        }
        url = reverse('app_name_room_update', args=[room.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ReservationViewTest(unittest.TestCase):
    '''
    Tests for Reservation
    '''
    def setUp(self):
        self.client = Client()

    def test_list_reservation(self):
        url = reverse('app_name_reservation_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_reservation(self):
        url = reverse('app_name_reservation_create')
        data = {
            "name": "name",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_reservation(self):
        reservation = create_reservation()
        url = reverse('app_name_reservation_detail', args=[reservation.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_reservation(self):
        reservation = create_reservation()
        data = {
            "name": "name",
        }
        url = reverse('app_name_reservation_update', args=[reservation.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ReasonViewTest(unittest.TestCase):
    '''
    Tests for Reason
    '''
    def setUp(self):
        self.client = Client()

    def test_list_reason(self):
        url = reverse('app_name_reason_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_reason(self):
        url = reverse('app_name_reason_create')
        data = {
            "name": "name",
            "description": "description",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_reason(self):
        reason = create_reason()
        url = reverse('app_name_reason_detail', args=[reason.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_reason(self):
        reason = create_reason()
        data = {
            "name": "name",
            "description": "description",
        }
        url = reverse('app_name_reason_update', args=[reason.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class UserViewTest(unittest.TestCase):
    '''
    Tests for User
    '''
    def setUp(self):
        self.client = Client()

    def test_list_user(self):
        url = reverse('app_name_user_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_user(self):
        url = reverse('app_name_user_create')
        data = {
            "name": "name",
            "email": "email",
            "admin": "admin",
            "password": "password",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_user(self):
        user = create_user()
        url = reverse('app_name_user_detail', args=[user.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_user(self):
        user = create_user()
        data = {
            "name": "name",
            "email": "email",
            "admin": "admin",
            "password": "password",
        }
        url = reverse('app_name_user_update', args=[user.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class calendarViewTest(unittest.TestCase):
    '''
    Tests for calendar
    '''
    def setUp(self):
        self.client = Client()

    def test_list_calendar(self):
        url = reverse('app_name_calendar_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_calendar(self):
        url = reverse('app_name_calendar_create')
        data = {
            "date": "date",
            "datetime": "datetime",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_calendar(self):
        calendar = create_calendar()
        url = reverse('app_name_calendar_detail', args=[calendar.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_calendar(self):
        calendar = create_calendar()
        data = {
            "date": "date",
            "datetime": "datetime",
        }
        url = reverse('app_name_calendar_update', args=[calendar.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class timeslotsViewTest(unittest.TestCase):
    '''
    Tests for timeslots
    '''
    def setUp(self):
        self.client = Client()

    def test_list_timeslots(self):
        url = reverse('app_name_timeslots_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_timeslots(self):
        url = reverse('app_name_timeslots_create')
        data = {
            "name": "name",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_timeslots(self):
        timeslots = create_timeslots()
        url = reverse('app_name_timeslots_detail', args=[timeslots.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_timeslots(self):
        timeslots = create_timeslots()
        data = {
            "name": "name",
        }
        url = reverse('app_name_timeslots_update', args=[timeslots.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


