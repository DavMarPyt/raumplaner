from django.contrib import admin
from django import forms
from .models import Room, Reservation, Reason, User, calendar, timeslots

class RoomAdminForm(forms.ModelForm):

    class Meta:
        model = Room
        fields = '__all__'


class RoomAdmin(admin.ModelAdmin):
    form = RoomAdminForm
    list_display = ['name', 'created', 'last_updated', 'roomnumber', 'building', 'email']
    readonly_fields = ['name', 'created', 'last_updated', 'roomnumber', 'building', 'email']

admin.site.register(Room, RoomAdmin)


class ReservationAdminForm(forms.ModelForm):

    class Meta:
        model = Reservation
        fields = '__all__'


class ReservationAdmin(admin.ModelAdmin):
    form = ReservationAdminForm
    list_display = ['name', 'created', 'last_updated']
    readonly_fields = ['name', 'created', 'last_updated']

admin.site.register(Reservation, ReservationAdmin)


class ReasonAdminForm(forms.ModelForm):

    class Meta:
        model = Reason
        fields = '__all__'


class ReasonAdmin(admin.ModelAdmin):
    form = ReasonAdminForm
    list_display = ['name', 'created', 'last_updated', 'description']
    readonly_fields = ['name', 'created', 'last_updated', 'description']

admin.site.register(Reason, ReasonAdmin)


class UserAdminForm(forms.ModelForm):

    class Meta:
        model = User
        fields = '__all__'


class UserAdmin(admin.ModelAdmin):
    form = UserAdminForm
    list_display = ['name', 'created', 'last_updated', 'email', 'admin', 'password']
    readonly_fields = ['name', 'created', 'last_updated', 'email', 'admin', 'password']

admin.site.register(User, UserAdmin)


class calendarAdminForm(forms.ModelForm):

    class Meta:
        model = calendar
        fields = '__all__'


class calendarAdmin(admin.ModelAdmin):
    form = calendarAdminForm
    list_display = ['date', 'datetime']
    readonly_fields = ['date', 'datetime']

admin.site.register(calendar, calendarAdmin)


class timeslotsAdminForm(forms.ModelForm):

    class Meta:
        model = timeslots
        fields = '__all__'


class timeslotsAdmin(admin.ModelAdmin):
    form = timeslotsAdminForm
    list_display = ['name', 'created', 'last_updated']
    readonly_fields = ['name', 'created', 'last_updated']

admin.site.register(timeslots, timeslotsAdmin)


