from django import forms
from .models import Room, Reservation, Reason, User, calendar, timeslots


class RoomForm(forms.ModelForm):
    class Meta:
        model = Room
        fields = ['name', 'roomnumber', 'building', 'email']


class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['name']


class ReasonForm(forms.ModelForm):
    class Meta:
        model = Reason
        fields = ['name', 'description']


class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['name', 'email', 'admin', 'password']


class calendarForm(forms.ModelForm):
    class Meta:
        model = calendar
        fields = ['date', 'datetime']


class timeslotsForm(forms.ModelForm):
    class Meta:
        model = timeslots
        fields = ['name']


