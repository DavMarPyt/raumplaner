from . import models

from rest_framework import serializers


class RoomSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Room
        fields = (
            'pk', 
            'name', 
            'created', 
            'last_updated', 
            'roomnumber', 
            'building', 
            'email', 
        )


class ReservationSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Reservation
        fields = (
            'pk', 
            'name', 
            'created', 
            'last_updated', 
        )


class ReasonSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Reason
        fields = (
            'pk', 
            'name', 
            'created', 
            'last_updated', 
            'description', 
        )


class UserSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.User
        fields = (
            'pk', 
            'name', 
            'created', 
            'last_updated', 
            'email', 
            'admin', 
            'password', 
        )


class calendarSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.calendar
        fields = (
            'pk', 
            'date', 
            'datetime', 
        )


class timeslotsSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.timeslots
        fields = (
            'pk', 
            'name', 
            'created', 
            'last_updated', 
        )


