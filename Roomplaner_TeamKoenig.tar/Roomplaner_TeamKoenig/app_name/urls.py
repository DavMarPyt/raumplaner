from django.urls import path, include
from rest_framework import routers

from . import api
from . import views

router = routers.DefaultRouter()
router.register(r'room', api.RoomViewSet)
router.register(r'reservation', api.ReservationViewSet)
router.register(r'reason', api.ReasonViewSet)
router.register(r'user', api.UserViewSet)
router.register(r'calendar', api.calendarViewSet)
router.register(r'timeslots', api.timeslotsViewSet)


urlpatterns = (
    # urls for Django Rest Framework API
    path('api/v1/', include(router.urls)),
)

urlpatterns += (
    # urls for Room
    path('app_name/room/', views.RoomListView.as_view(), name='app_name_room_list'),
    path('app_name/room/create/', views.RoomCreateView.as_view(), name='app_name_room_create'),
    path('app_name/room/detail/<int:pk>/', views.RoomDetailView.as_view(), name='app_name_room_detail'),
    path('app_name/room/update/<int:pk>/', views.RoomUpdateView.as_view(), name='app_name_room_update'),
)

urlpatterns += (
    # urls for Reservation
    path('app_name/reservation/', views.ReservationListView.as_view(), name='app_name_reservation_list'),
    path('app_name/reservation/create/', views.ReservationCreateView.as_view(), name='app_name_reservation_create'),
    path('app_name/reservation/detail/<int:pk>/', views.ReservationDetailView.as_view(), name='app_name_reservation_detail'),
    path('app_name/reservation/update/<int:pk>/', views.ReservationUpdateView.as_view(), name='app_name_reservation_update'),
)

urlpatterns += (
    # urls for Reason
    path('app_name/reason/', views.ReasonListView.as_view(), name='app_name_reason_list'),
    path('app_name/reason/create/', views.ReasonCreateView.as_view(), name='app_name_reason_create'),
    path('app_name/reason/detail/<int:pk>/', views.ReasonDetailView.as_view(), name='app_name_reason_detail'),
    path('app_name/reason/update/<int:pk>/', views.ReasonUpdateView.as_view(), name='app_name_reason_update'),
)

urlpatterns += (
    # urls for User
    path('app_name/user/', views.UserListView.as_view(), name='app_name_user_list'),
    path('app_name/user/create/', views.UserCreateView.as_view(), name='app_name_user_create'),
    path('app_name/user/detail/<int:pk>/', views.UserDetailView.as_view(), name='app_name_user_detail'),
    path('app_name/user/update/<int:pk>/', views.UserUpdateView.as_view(), name='app_name_user_update'),
)

urlpatterns += (
    # urls for calendar
    path('app_name/calendar/', views.calendarListView.as_view(), name='app_name_calendar_list'),
    path('app_name/calendar/create/', views.calendarCreateView.as_view(), name='app_name_calendar_create'),
    path('app_name/calendar/detail/<int:pk>/', views.calendarDetailView.as_view(), name='app_name_calendar_detail'),
    path('app_name/calendar/update/<int:pk>/', views.calendarUpdateView.as_view(), name='app_name_calendar_update'),
)

urlpatterns += (
    # urls for timeslots
    path('app_name/timeslots/', views.timeslotsListView.as_view(), name='app_name_timeslots_list'),
    path('app_name/timeslots/create/', views.timeslotsCreateView.as_view(), name='app_name_timeslots_create'),
    path('app_name/timeslots/detail/<int:pk>/', views.timeslotsDetailView.as_view(), name='app_name_timeslots_detail'),
    path('app_name/timeslots/update/<int:pk>/', views.timeslotsUpdateView.as_view(), name='app_name_timeslots_update'),
)

